# Mateen Pay — Android starter project

Developer: Mateen Qureshi

## What this starter does
- Provides a basic Mateen Pay home screen.
- Lets a user enter a UPI payee ID, name, amount and note.
- Opens a compatible UPI app using the standard `upi://pay` intent.
- Clearly does **not** claim that a payment succeeded.
- Provides KYC information only; it does not collect Aadhaar numbers, OTPs, biometrics or documents.

## Important production limitations
This is a starter project, not a licensed wallet, bank app, PSP app, or production payment processor.
- A UPI intent handoff is not proof of payment. Do not credit balances or mark transactions successful based only on the app returning to the foreground.
- For verified payment status, use an authorized PSP/payment provider's documented integration and server-side signed/webhook/status verification.
- Aadhaar KYC must be handled through an appropriately authorized provider and compliant UIDAI process. Never collect Aadhaar OTPs or biometrics directly in this app.
- Do not store customer funds or offer a wallet unless the required regulated partner, authorization and compliance framework is in place.
- Before production, add backend authentication, authorization, rate limiting, audit logs, fraud controls, secure secrets management, privacy/consent flows, data retention controls and independent security testing.

## Build on an Android phone
1. Install a maintained Android development IDE that supports Gradle Android projects, or use a trusted cloud development environment.
2. Extract this ZIP into a folder named `MateenPay`.
3. Open/import the folder containing `settings.gradle`.
4. Allow Gradle to sync. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35 and Java 17.
5. Build the `app` debug variant and install it on your own test phone.
6. Test only with a small amount and a trusted recipient after checking all details in your UPI app. Do not use real customer funds during development.

If your phone IDE cannot sync this Gradle version or download SDK 35, use a cloud Android build environment or a PC with Android Studio. Do not download random APKs or Gradle plugins from unofficial sites.
