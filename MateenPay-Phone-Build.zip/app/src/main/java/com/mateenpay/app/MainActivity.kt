package com.mateenpay.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.text.InputType
import java.net.URLEncoder

class MainActivity : Activity() {
    private val purple = Color.rgb(118, 87, 246)
    private val ink = Color.rgb(25, 23, 48)
    private val muted = Color.rgb(110, 108, 130)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(20))
            setBackgroundColor(Color.rgb(247, 246, 252))
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(5), 0, dp(5))
        }
    }

    private fun button(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
            setOnClickListener { action() }
        }
    }

    private fun showHome() {
        val root = baseLayout()
        root.addView(text("MATEEN PAY", 13f, purple, true))
        root.addView(text("Payments, made simple.", 27f, ink, true))
        root.addView(text("Developer: Mateen Qureshi", 13f, muted))
        val spacer = Space(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, dp(18)))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(ink)
        }
        card.addView(text("AVAILABLE BALANCE", 12f, Color.LTGRAY, true))
        card.addView(text("₹ 0.00", 32f, Color.WHITE, true))
        card.addView(text("Starter preview · no stored funds", 12f, Color.LTGRAY))
        root.addView(card, LinearLayout.LayoutParams(-1, -2))

        root.addView(text("Quick actions", 19f, ink, true).apply {
            setPadding(0, dp(22), 0, dp(8))
        })
        root.addView(button("Send via UPI app") { showUpiForm() },
            LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(button("KYC information") { showKycInfo() },
            LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })
        root.addView(button("Transaction history") {
            showMessage("No transactions yet. Payment history will appear here after a verified provider integration.")
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })

        root.addView(text(
            "Safety: This starter app does not collect Aadhaar numbers or OTPs, hold money, or verify UPI payment success.",
            12f, muted
        ).apply { setPadding(0, dp(20), 0, 0) })
        setContentView(root)
    }

    private fun showUpiForm() {
        val root = baseLayout()
        root.addView(text("Send via UPI", 25f, ink, true))
        root.addView(text("This hands the payment request to a UPI app installed on your phone. Check the payee and amount there before approving.", 14f, muted))
        val payee = EditText(this).apply {
            hint = "Payee UPI ID (example@upi)"
            singleLine = true
        }
        val name = EditText(this).apply {
            hint = "Payee name"
            singleLine = true
        }
        val amount = EditText(this).apply {
            hint = "Amount in INR"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            singleLine = true
        }
        val note = EditText(this).apply {
            hint = "Payment note (optional)"
            singleLine = true
        }
        listOf(payee, name, amount, note).forEach {
            root.addView(it, LinearLayout.LayoutParams(-1, dp(54)))
        }
        root.addView(button("Continue to UPI app") {
            val id = payee.text.toString().trim()
            val payeeName = name.text.toString().trim()
            val amt = amount.text.toString().trim()
            val memo = note.text.toString().trim()
            if (!id.contains("@") || payeeName.isBlank() || amt.toDoubleOrNull() == null || amt.toDouble() <= 0) {
                showMessage("Enter a valid UPI ID, payee name and positive amount.")
                return@button
            }
            try {
                val uri = Uri.parse(
                    "upi://pay?pa=${enc(id)}&pn=${enc(payeeName)}&am=${enc(amt)}&cu=INR&tn=${enc(memo)}"
                )
                startActivity(Intent(Intent.ACTION_VIEW, uri))
                showMessage("UPI app opened. Mateen Pay cannot confirm payment status. Verify the result in your UPI app/bank.")
            } catch (_: ActivityNotFoundException) {
                showMessage("No compatible UPI app was found on this phone.")
            } catch (_: Exception) {
                showMessage("Could not open the UPI payment app.")
            }
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(18) })
        root.addView(button("Back to home") { showHome() },
            LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        setContentView(root)
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun showKycInfo() {
        val root = baseLayout()
        root.addView(text("Identity verification", 25f, ink, true))
        root.addView(text(
            "Production Aadhaar-based KYC must be completed through an authorized KYC provider and the applicable UIDAI-approved process. This starter app intentionally does not ask for Aadhaar numbers, OTPs, biometrics or identity-document uploads.",
            15f, muted
        ))
        root.addView(text(
            "Before launch: onboard with a regulated bank/payment partner, complete provider compliance checks, secure backend integration, privacy notices, consent flows and security testing.",
            15f, ink
        ))
        root.addView(button("Back to home") { showHome() },
            LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(20) })
        setContentView(root)
    }

    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
